print("hello")
name = input('What is your name?')
print('Hi ->' + name)

double= "Prudence's love is amaizing"

print(double)

